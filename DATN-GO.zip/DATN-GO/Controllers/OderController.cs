﻿using Microsoft.AspNetCore.Mvc;

namespace DATN_GO.Controllers
{
    public class OderController : Controller
    {
        public IActionResult Oder()
        {
            return View();
        }
    }
}
