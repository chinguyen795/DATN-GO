﻿using Microsoft.AspNetCore.Mvc;

namespace DATN_GO.Controllers
{
    public class policyController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
