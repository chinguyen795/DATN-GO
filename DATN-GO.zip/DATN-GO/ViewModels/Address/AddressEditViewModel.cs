﻿namespace DATN_GO.ViewModels.Address
{
    public class AddressEditViewModel : AddressCreateViewModel
    {
        public int Id { get; set; }
    }

}