﻿namespace DATN_GO.ViewModels.Address
{
    public class WardViewModel
    {
        public int Id { get; set; }
        public string WardName { get; set; } = string.Empty;
        public int DistrictId { get; set; }
    }

}