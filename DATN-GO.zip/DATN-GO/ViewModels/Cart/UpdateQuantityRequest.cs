﻿namespace DATN_GO.ViewModels.Cart
{
    public class UpdateQuantityRequest
    {
        public int CartId { get; set; }
        public int NewQuantity { get; set; }
    }
}
