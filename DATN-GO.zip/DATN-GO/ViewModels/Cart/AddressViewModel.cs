﻿namespace DATN_GO.ViewModels.Cart
{
    public class AddressViewModel
    {
        public int Id { get; set; }
        public string FullAddress { get; set; }
    }

}
