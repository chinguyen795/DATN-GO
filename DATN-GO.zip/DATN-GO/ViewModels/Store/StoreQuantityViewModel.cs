﻿namespace DATN_GO.ViewModels.Store
{
    public class StoreQuantityViewModel
    {
        public int StoreId { get; set; }
        public int TotalProductQuantity { get; set; }
        public int TotalCartQuantity { get; set; }
    }

}