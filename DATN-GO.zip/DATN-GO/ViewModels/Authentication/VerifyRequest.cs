
namespace DATN_GO.ViewModels.Authentication
{
public class VerifyRequest
{
    public string Identifier { get; set; }
    public string Code { get; set; }
}
}
