﻿using DATN_GO.ViewModels;
using DATN_GO.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading.Tasks;
using DATN_GO.ViewModels.Orders;

namespace DATN_GO.Service
{
    public class OrderService
    {
        private readonly HttpClient _httpClient;
        private readonly string _baseUrl;
        private static readonly JsonSerializerOptions _jsonOpts = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };

        public OrderService(HttpClient httpClient, IConfiguration config)
        {
            _httpClient = httpClient;
            _baseUrl = config.GetValue<string>("ApiSettings:BaseUrl")?.TrimEnd('/') + "/";
        }

        // ===== CRUD cơ bản (ViewModel tổng quát) =====

        public async Task<List<OrderViewModel>> GetAllAsync()
        {
            var response = await _httpClient.GetAsync(_baseUrl + "orders");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<List<OrderViewModel>>(_jsonOpts);
        }

        public async Task<OrderViewModel?> GetByIdAsync(int id)
        {
            var response = await _httpClient.GetAsync($"{_baseUrl}orders/{id}");
            if (!response.IsSuccessStatusCode) return null;
            return await response.Content.ReadFromJsonAsync<OrderViewModel>(_jsonOpts);
        }

        public async Task<OrderViewModel?> CreateAsync(OrderViewModel model)
        {
            var response = await _httpClient.PostAsJsonAsync($"{_baseUrl}orders", model);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<OrderViewModel>(_jsonOpts);
        }

        public async Task<bool> UpdateAsync(int id, OrderViewModel model)
        {
            var response = await _httpClient.PutAsJsonAsync($"{_baseUrl}orders/{id}", model);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var response = await _httpClient.DeleteAsync($"{_baseUrl}orders/{id}");
            return response.IsSuccessStatusCode;
        }

        // ===== Danh sách theo store / user =====

        public async Task<(bool Success, List<OrderViewModel>? Data, string? Message)> GetOrdersByStoreUserAsync(int userId)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_baseUrl}orders/all-by-store/{userId}");
                if (!response.IsSuccessStatusCode) return (false, null, $"Lỗi {response.StatusCode}");
                var data = await response.Content.ReadFromJsonAsync<List<OrderViewModel>>(_jsonOpts);
                return (true, data ?? new List<OrderViewModel>(), null);
            }
            catch (Exception ex)
            {
                return (false, null, ex.Message);
            }
        }

        public async Task<(bool Success, List<OrderViewModel>? Data, string? Message)> GetOrdersByUserAsync(int userId)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_baseUrl}orders/all-by-user/{userId}");
                if (!response.IsSuccessStatusCode) return (false, null, $"Lỗi {response.StatusCode}");
                var data = await response.Content.ReadFromJsonAsync<List<OrderViewModel>>(_jsonOpts);
                return (true, data ?? new List<OrderViewModel>(), null);
            }
            catch (Exception ex)
            {
                return (false, null, ex.Message);
            }
        }

        public async Task<(bool Success, Statistics? Data, string? Message)> GetStatisticsAsync(
    int userId, DateTime? start, DateTime? end, DateTime? startCompare = null, DateTime? endCompare = null)
        {
            try
            {
                // ✅ Gọi API mới: statistics-by-user/{userId}
                var url = $"{_baseUrl}orders/statistics-by-user/{userId}";

                if (start.HasValue)
                    url += $"&start={start.Value:O}";
                if (end.HasValue)
                    url += $"&end={end.Value:O}";
                if (startCompare.HasValue)
                    url += $"&startCompare={startCompare.Value:O}";
                if (endCompare.HasValue)
                    url += $"&endCompare={endCompare.Value:O}";

                // Vì dùng query string nên cần thêm "?" trước tham số đầu tiên
                url = url.Replace($"{userId}&", $"{userId}?");

                var response = await _httpClient.GetAsync(url);
                if (!response.IsSuccessStatusCode)
                    return (false, null, $"Lỗi {response.StatusCode}");

                var data = await response.Content.ReadFromJsonAsync<Statistics>();
                return (true, data, null);
            }
            catch (Exception ex)
            {
                return (false, null, ex.Message);
            }
        }




        public async Task<(bool Success, string Message)> UpdateStatusAsync(int id, string newStatus)
        {
            try
            {
                var req = new HttpRequestMessage(new HttpMethod("PATCH"), $"{_baseUrl}orders/updatestatus/{id}?status={newStatus}");
                var response = await _httpClient.SendAsync(req);
                var message = await response.Content.ReadAsStringAsync();
                return (response.IsSuccessStatusCode, message);
            }
            catch (Exception ex)
            {
                return (false, $"Lỗi kết nối: {ex.Message}");
            }
        }

        // =====================================================================
        //  PHẦN QUAN TRỌNG CHO TRANG CHI TIẾT ĐƠN (OrderUser/Detail)
        //  -> Trả về OrderDetailVM đã map sẵn DeliveryFee + LabelId + tính tổng
        // =====================================================================

        /// <summary>
        /// Lấy chi tiết đơn theo quyền user (API: GET /api/orders/{orderId}/user/{userId})
        /// Map sang OrderDetailVM cho View Razor.
        /// </summary>
        public async Task<OrderDetailVM?> GetOrderDetailByIdAsync(int orderId, int userId)
        {
            try
            {
                var res = await _httpClient.GetAsync($"{_baseUrl}orders/{orderId}/user/{userId}");
                if (!res.IsSuccessStatusCode) return null;

                var vm = await res.Content.ReadFromJsonAsync<OrderDetailVM>(
                    new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                if (vm == null) return null;

                // Nếu API chưa set TotalPrice, tự cộng ItemsTotal + DeliveryFee để hiển thị
                if (vm.TotalPrice <= 0)
                    vm.TotalPrice = vm.ItemsTotal + vm.DeliveryFee;

                return vm;
            }
            catch
            {
                return null;
            }
        }



        /// <summary>
        /// (Tuỳ chọn) Lấy chi tiết theo endpoint chuyên biệt: GET /api/orders/{id}/detail
        /// Endpoint này trả thẳng OrderDetailDto -> map 1:1 sang OrderDetailVM.
        /// </summary>
        public async Task<OrderDetailVM?> GetDetailAsync(int orderId)
        {
            var res = await _httpClient.GetAsync($"{_baseUrl}orders/{orderId}/detail");
            if (!res.IsSuccessStatusCode) return null;

            var vm = await res.Content.ReadFromJsonAsync<OrderDetailVM>(_jsonOpts);
            if (vm == null) return null;

            // Fallback an toàn: nếu TotalPrice = 0 thì tự cộng
            if (vm.TotalPrice <= 0)
            {
                var itemsTotal = vm.Items?.Sum(i => i.SubTotal) ?? 0m;
                vm.TotalPrice = itemsTotal + vm.DeliveryFee;
            }
            return vm;
        }

        // ===== Phần cũ: lấy chi tiết qua OrderViewModel (không dùng cho view Detail) =====

        public async Task<(bool Success, List<OrderDetailViewModel>? Data, string? Message)> GetOrderDetailsByOrderIdAsync(int orderId)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_baseUrl}orders/{orderId}");
                if (!response.IsSuccessStatusCode) return (false, null, $"Lỗi {response.StatusCode}");

                var order = await response.Content.ReadFromJsonAsync<OrderViewModel>(_jsonOpts);
                if (order == null) return (false, null, "Không tìm thấy đơn");

                return (true, order.OrderDetails ?? new List<OrderDetailViewModel>(), null);
            }
            catch (Exception ex)
            {
                return (false, null, ex.Message);
            }
        }
        public async Task<(bool Success, Dictionary<int, decimal>? Data, string? Message)>
    GetTotalPriceByMonthAsync(int year, int storeId)
        {
            try
            {
                var url = $"{_baseUrl}orders/totalprice/by-month/{year}/store/{storeId}";
                var res = await _httpClient.GetAsync(url);

                if (!res.IsSuccessStatusCode)
                    return (false, null, $"API lỗi {res.StatusCode}");

                // API giả sử trả về JSON kiểu { "1": 100000, "2": 200000, ... }
                var data = await res.Content.ReadFromJsonAsync<Dictionary<int, decimal>>(_jsonOpts);

                return (true, data ?? new Dictionary<int, decimal>(), null);
            }
            catch (Exception ex)
            {
                return (false, null, ex.Message);
            }
        }
        public async Task<int> GetTotalOrdersByStoreIdAsync(int storeId)
        {
            try
            {
                var url = $"{_baseUrl}orders/count/store/{storeId}";
                return await _httpClient.GetFromJsonAsync<int>(url);
            }
            catch (HttpRequestException ex)
            {
                Console.WriteLine($"❌ Lỗi gọi API GetTotalOrdersByStoreIdAsync: {ex.Message}");
                return 0;
            }
        }
        public async Task<(bool Success, string Message)> SendRevenueReportAllStoresCurrentMonthAsync()
        {
            try
            {
                var url = $"{_baseUrl}orders/send/all/current-month";
                var response = await _httpClient.PostAsync(url, null); // POST không có body

                var message = await response.Content.ReadAsStringAsync();
                return (response.IsSuccessStatusCode, message);
            }
            catch (Exception ex)
            {
                return (false, $"Lỗi khi gọi API: {ex.Message}");
            }
        }
        public async Task<decimal> GetTotalRevenueAsync()
        {
            var url = $"{_baseUrl}orders/total-revenue"; // ✅ dùng baseUrl để tránh sai endpoint
            var response = await _httpClient.GetAsync(url);
            response.EnsureSuccessStatusCode();

            var revenue = await response.Content.ReadFromJsonAsync<decimal>(_jsonOpts);
            return revenue;
        }
        public async Task<(bool Success, string Message)> CheckoutCODAsync(int orderId)
        {
            try
            {
                var response = await _httpClient.PostAsync($"{_baseUrl}payment/cod/{orderId}", null);
                var msg = await response.Content.ReadAsStringAsync();
                return (response.IsSuccessStatusCode, msg);
            }
            catch (Exception ex)
            {
                return (false, $"Lỗi gọi API COD: {ex.Message}");
            }
        }


        public async Task<(bool Success, string Message)> CancelOrderAsync(int orderId, int userId)
        {
            try
            {
                var url = $"{_baseUrl}orders/{orderId}/cancel/user/{userId}";
                var response = await _httpClient.PostAsync(url, null); // POST không cần body

                var message = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine($"[OrderService] ✅ Hủy đơn {orderId} thành công. API trả: {message}");
                    return (true, "Đơn hàng đã được hủy thành công.");
                }
                else
                {
                    Console.WriteLine($"[OrderService] ❌ Hủy đơn {orderId} thất bại. API trả: {message}");
                    return (false, $"Hủy đơn thất bại: {message}");
                }
            }
            catch (Exception ex)
            {
                return (false, $"Lỗi khi gọi API hủy đơn: {ex.Message}");
            }
        }

    }
}