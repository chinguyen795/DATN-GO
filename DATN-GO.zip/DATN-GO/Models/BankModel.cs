﻿namespace DATN_GO.Models
{
    public class BankModel
    {
        public string Bin { get; set; }
        public string Name { get; set; }
        public string ShortName { get; set; }
        public string Logo { get; set; }
    }

}
