using DATN_API.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DATN_API.Interfaces
{
    public interface IPricesService
    {
        Task<IEnumerable<Prices>> GetAllAsync();
        Task<Prices> GetByIdAsync(int id);
        Task<Prices> CreateAsync(Prices model);
        Task<bool> UpdateAsync(int id, Prices model);
        Task<bool> DeleteAsync(int id);
        Task<decimal?> GetMinPriceByProductIdAsync(int productId);
        Task<object> GetMinMaxPriceByProductIdAsync(int productId);
        Task<decimal?> GetPriceByProductIdAsync(int productId);

    }
}
