﻿namespace DATN_API.ViewModels.Cart
{
    public class AddressViewModel
    {
        public int Id { get; set; }
        public string FullAddress { get; set; }
    }

}
