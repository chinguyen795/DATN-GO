﻿using DATN_API.Data;
using DATN_API.Interfaces;
using DATN_API.Models;
using DATN_API.Services.Interfaces;
using DATN_API.ViewModels.Vnpay;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DATN_API.ViewModels.Orders;

namespace DATN_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PaymentController : ControllerBase
    {
        private readonly ApplicationDbContext _db;
        private readonly ICartService _cartService;
        private readonly IVNPayService _vnp;
        private readonly IOrdersService _orders;

        public PaymentController(ApplicationDbContext db, ICartService cartService, IVNPayService vnp, IOrdersService orders)
        {
            _db = db; _cartService = cartService; _vnp = vnp; _orders = orders;
        }

        // DTO từ MVC gửi lên khi bấm thanh toán
        public class CreateVnpOrderRequest
        {
            public int UserId { get; set; }
            public int AddressId { get; set; }
            public int? UserVoucherId { get; set; }
        }

        [HttpPost("vnpay-create")]
        public async Task<IActionResult> CreateVnpay([FromBody] CreateVnpOrderRequest req)
        {
            var cart = await _cartService.GetCartByUserIdAsync(req.UserId);
            if (cart == null) return BadRequest("Cart not found");

            var shippingGroups = await _cartService.GetShippingGroupsByUserIdAsync(req.UserId, req.AddressId);
            var shippingFee = shippingGroups.Sum(g => g.ShippingFee);

            var selected = cart.CartItems.Where(x => x.IsSelected).ToList();
            if (!selected.Any()) return BadRequest("Không có sản phẩm nào được chọn.");

            var subTotal = selected.Sum(x => x.TotalValue);

            // --- TÍNH GIẢM TỪ USER_VOUCHER (nếu có) ---
            int? voucherId = null;
            decimal voucherReduce = 0m;

            if (req.UserVoucherId.HasValue)
            {
                var uv = await _db.UserVouchers
                    .Include(x => x.Voucher)
                    .FirstOrDefaultAsync(x => x.Id == req.UserVoucherId.Value
                                           && x.UserId == req.UserId
                                           && !x.IsUsed);
                if (uv?.Voucher != null)
                {
                    var v = uv.Voucher;
                    // điều kiện tối thiểu
                    if (DateTime.UtcNow >= v.StartDate && DateTime.UtcNow <= v.EndDate && subTotal >= v.MinOrder
                        && (v.Quantity == null || v.UsedCount < v.Quantity))
                    {
                        // tính giảm: cố định / %
                        if (v.IsPercentage)
                        {
                            var perc = Math.Clamp((double)v.Reduce, 0d, 100d);
                            voucherReduce = subTotal * (decimal)(perc / 100d);
                            if (v.MaxDiscount is decimal cap && cap > 0 && voucherReduce > cap)
                                voucherReduce = cap;
                        }
                        else
                        {
                            voucherReduce = Math.Min(v.Reduce, subTotal);
                        }

                        // đánh dấu dùng
                        voucherId = v.Id;
                        uv.IsUsed = true;
                        v.UsedCount = (v.UsedCount ?? 0) + 1;
                    }
                }
            }

            var grandTotal = (long)Math.Max(0, subTotal + shippingFee - voucherReduce);

            // đảm bảo ShippingMethod
            var representativeStoreId = selected.First().StoreId;
            var shipMethod = await _db.ShippingMethods
                .FirstOrDefaultAsync(sm => sm.StoreId == representativeStoreId && sm.MethodName == "GHTK_AUTO");
            if (shipMethod == null)
            {
                shipMethod = new ShippingMethods { StoreId = representativeStoreId, MethodName = "GHTK_AUTO", Price = 0 };
                _db.ShippingMethods.Add(shipMethod);
                await _db.SaveChangesAsync();
            }

            // --- TẠO ĐƠN: gắn VoucherId và DeliveryFee, TotalPrice đã TRỪ VOUCHER ---
            var order = new Orders
            {
                UserId = req.UserId,
                OrderDate = DateTime.UtcNow,
                PaymentMethod = "VNPAY",
                PaymentStatus = "Unpaid",
                Status = OrderStatus.ChoXuLy,
                TotalPrice = grandTotal,
                DeliveryFee = shippingFee,
                VoucherId = voucherId,
                ShippingMethodId = shipMethod.Id
            };
            _db.Orders.Add(order);
            await _db.SaveChangesAsync();

            foreach (var item in selected)
            {
                _db.OrderDetails.Add(new OrderDetails
                {
                    OrderId = order.Id,
                    ProductId = item.ProductId,
                    Quantity = item.Quantity,
                    Price = item.Price
                });
            }
            await _db.SaveChangesAsync();

            var clientIp = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1";
            var paymentUrl = _vnp.CreatePaymentUrl(new VnpCreatePaymentRequest
            {
                OrderId = order.Id.ToString(),
                Amount = grandTotal,
                OrderInfo = $"Thanh toan don hang #{order.Id}",
                IpAddress = clientIp,
                Locale = "vn"
            });

            return Ok(new { paymentUrl });
        }


        // Controllers/PaymentController.cs

        [HttpGet("vnpay-return")]
        public async Task<IActionResult> VnpReturn()
        {
            var raw = Request.Query.ToDictionary(k => k.Key, v => v.Value.ToString());
            var isValid = _vnp.ValidateReturn(raw);

            var orderId = raw.TryGetValue("vnp_TxnRef", out var refId) ? refId : null;
            var rspCode = raw.TryGetValue("vnp_ResponseCode", out var rc) ? rc : null;
            if (orderId == null) return BadRequest("Missing order id");

            var order = await _db.Orders.FirstOrDefaultAsync(o => o.Id.ToString() == orderId);
            if (order == null) return NotFound("Order not found");

            if (isValid && rspCode == "00")
            {
                order.PaymentStatus = "Paid";
                order.Status = OrderStatus.ChoLayHang;   // hoặc trạng thái bạn dùng
                order.PaymentDate = DateTime.UtcNow;

                // 💥 xoá các item đã tick trong giỏ
                try { await _cartService.ClearSelectedAsync(order.UserId); } catch { }

                await _db.SaveChangesAsync();
                // 🔗 Tạo đơn GHTK & lưu LabelId (tránh trùng)
                try
                {
                    if (string.IsNullOrEmpty(order.LabelId))
                    {
                        var label = await _orders.PushOrderToGhtkAndSaveLabelAsync(order.Id);
                        // optional: log label
                    }
                }
                catch { /* log nếu cần */ }

                return Redirect($"https://localhost:7180/Checkout/Success?orderId={order.Id}");
            }
            else
            {
                if (order.PaymentStatus != "Paid")
                {
                    order.PaymentStatus = "Failed";
                    order.Status = OrderStatus.ChoXuLy;
                    await _db.SaveChangesAsync();
                }
                return Redirect($"https://localhost:7180/Checkout/Failure?orderId={order.Id}");
            }
        }

        [HttpGet("vnpay-ipn")]
        public async Task<IActionResult> VnpIpn()
        {
            var query = Request.Query.ToDictionary(k => k.Key, v => v.Value.ToString());
            var valid = _vnp.ValidateReturn(query);
            var rspCode = query.GetValueOrDefault("vnp_ResponseCode");
            var txnRef = query.GetValueOrDefault("vnp_TxnRef");

            if (!valid) return new JsonResult(new { RspCode = "97", Message = "Invalid signature" });

            var order = await _db.Orders.FirstOrDefaultAsync(o => o.Id.ToString() == txnRef);
            if (order == null) return new JsonResult(new { RspCode = "01", Message = "Order not found" });

            if (rspCode == "00")
            {
                if (order.PaymentStatus != "Paid")
                {
                    order.PaymentStatus = "Paid";
                    order.Status = OrderStatus.DaHoanThanh;
                    order.PaymentDate = DateTime.UtcNow;

                    // 💥 idempotent: cứ thử xoá, nếu hết rồi thì count=0
                    try { await _cartService.ClearSelectedAsync(order.UserId); } catch { }

                    await _db.SaveChangesAsync();
                    // 🔗 Tạo đơn GHTK & lưu LabelId (tránh trùng)
                    try
                    {
                        if (string.IsNullOrEmpty(order.LabelId))
                        {
                            var label = await _orders.PushOrderToGhtkAndSaveLabelAsync(order.Id);
                        }
                    }
                    catch { /* log nếu cần */ }
                }
                return new JsonResult(new { RspCode = "00", Message = "Success" });
            }
            else
            {
                if (order.PaymentStatus != "Paid")
                {
                    order.PaymentStatus = "Failed";
                    await _db.SaveChangesAsync();
                }
                return new JsonResult(new { RspCode = "00", Message = "Success" });
            }
        }
        [HttpPost("test-ghtk/{orderId:int}")]
        public async Task<IActionResult> TestGhtk(int orderId)
        {
            var label = await _orders.PushOrderToGhtkAndSaveLabelAsync(orderId);
            return Ok(new { orderId, label });
        }
        [HttpPost("cod/{orderId}")]
        public async Task<IActionResult> CheckoutCOD(int orderId)
        {
            var label = await _orders.PushOrderToGhtkAndSaveLabelCodAsync(orderId);

            if (string.IsNullOrEmpty(label))
                return BadRequest(new { message = "Không tạo được đơn COD bên GHTK." });

            return Ok(new
            {
                message = "Đặt hàng COD thành công.",
                labelId = label
            });
        }
        [HttpPost("cod-create")]
        public async Task<IActionResult> CreateCod([FromBody] CreateVnpOrderRequest req)
        {
            if (req == null || req.UserId <= 0 || req.AddressId <= 0)
                return BadRequest(new { message = "Thiếu UserId/AddressId" });

            await using var tx = await _db.Database.BeginTransactionAsync();
            try
            {
                var cart = await _cartService.GetCartByUserIdAsync(req.UserId);
                if (cart == null) return BadRequest(new { message = "Cart not found" });

                var shippingGroups = await _cartService.GetShippingGroupsByUserIdAsync(req.UserId, req.AddressId);
                if (shippingGroups == null || !shippingGroups.Any())
                    return BadRequest(new { message = "Không tính được phí vận chuyển." });

                var shippingFee = shippingGroups.Sum(g => g.ShippingFee);
                var selected = cart.CartItems.Where(x => x.IsSelected).ToList();
                if (!selected.Any()) return BadRequest(new { message = "Không có sản phẩm nào được chọn." });

                var subTotal = selected.Sum(x => x.TotalValue);

                // --- LẤY USER_VOUCHER + TÍNH GIẢM & GẮN VoucherId ---
                int? voucherId = null;
                decimal voucherReduce = 0m;

                if (req.UserVoucherId.HasValue)
                {
                    var uv = await _db.UserVouchers
                        .Include(x => x.Voucher)
                        .FirstOrDefaultAsync(x => x.Id == req.UserVoucherId.Value
                                               && x.UserId == req.UserId
                                               && !x.IsUsed);

                    if (uv != null)
                    {
                        voucherId = uv.VoucherId;
                        uv.IsUsed = true;
                        if (uv.Voucher != null)
                        {
                            uv.Voucher.UsedCount = (uv.Voucher.UsedCount ?? 0) + 1;

                            // (Tối thiểu) giảm theo số tiền cố định
                            voucherReduce = uv.Voucher.IsPercentage
                                ? Math.Min(
                                      uv.Voucher.MaxDiscount ?? decimal.MaxValue,
                                      (subTotal * (uv.Voucher.Reduce / 100m)))
                                : Math.Min(uv.Voucher.Reduce, subTotal);
                        }
                    }
                }

                var grandTotal = (long)Math.Max(0, subTotal + shippingFee - voucherReduce);

                var representativeStoreId = selected.First().StoreId;
                var shipMethod = await _db.ShippingMethods
                    .FirstOrDefaultAsync(sm => sm.StoreId == representativeStoreId && sm.MethodName == "GHTK_AUTO");
                if (shipMethod == null)
                {
                    shipMethod = new ShippingMethods { StoreId = representativeStoreId, MethodName = "GHTK_AUTO", Price = 0 };
                    _db.ShippingMethods.Add(shipMethod);
                    await _db.SaveChangesAsync();
                }

                var order = new Orders
                {
                    UserId = req.UserId,
                    OrderDate = DateTime.UtcNow,
                    PaymentMethod = "COD",
                    PaymentStatus = "Unpaid",
                    Status = OrderStatus.ChoXuLy,
                    TotalPrice = grandTotal,      // <-- ĐÃ TRỪ VOUCHER
                    DeliveryFee = shippingFee,
                    VoucherId = voucherId,        // <-- LƯU voucher
                    ShippingMethodId = shipMethod.Id
                };
                _db.Orders.Add(order);
                await _db.SaveChangesAsync();

                foreach (var item in selected)
                {
                    _db.OrderDetails.Add(new OrderDetails
                    {
                        OrderId = order.Id,
                        ProductId = item.ProductId,
                        Quantity = item.Quantity,
                        Price = item.Price
                    });
                }
                await _db.SaveChangesAsync();

                // Đẩy GHTK COD
                var label = await _orders.PushOrderToGhtkAndSaveLabelCodAsync(order.Id);
                if (string.IsNullOrWhiteSpace(label))
                {
                    await tx.RollbackAsync();
                    _db.OrderDetails.RemoveRange(_db.OrderDetails.Where(d => d.OrderId == order.Id));
                    _db.Orders.Remove(order);
                    await _db.SaveChangesAsync();
                    return BadRequest(new { message = "Không tạo được đơn COD bên GHTK." });
                }

                order.Status = OrderStatus.ChoLayHang;
                order.LabelId = label;
                await _db.SaveChangesAsync();

                await _cartService.ClearSelectedAsync(order.UserId);
                await tx.CommitAsync();

                return Ok(new { orderId = order.Id, labelId = label });
            }
            catch (Exception e)
            {
                await tx.RollbackAsync();
                return StatusCode(500, new { message = "Lỗi hệ thống khi tạo đơn COD.", detail = e.Message });
            }
        }
        private static decimal CalcVoucherDiscount(Vouchers v, decimal orderSubtotal)
        {
            if (v == null) return 0m;
            if (orderSubtotal < v.MinOrder) return 0m;

            if (v.IsPercentage)
            {
                var perc = Math.Clamp((double)v.Reduce, 0d, 100d);
                var disc = orderSubtotal * (decimal)(perc / 100d);
                if (v.MaxDiscount is decimal cap && cap > 0 && disc > cap) disc = cap;
                return Math.Max(0m, disc);
            }
            // tiền cố định
            return Math.Max(0m, Math.Min(v.Reduce, orderSubtotal));
        }




    }
}