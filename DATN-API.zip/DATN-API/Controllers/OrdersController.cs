﻿using DATN_API.Data;
using DATN_API.Models;
using DATN_API.Services;
using DATN_API.Services.Interfaces;
using DATN_API.ViewModels.Orders;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DATN_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly ApplicationDbContext _db;

        private readonly IOrdersService _service;


        // ✅ Chỉ duy nhất 1 constructor – inject cả DbContext & Service
        public OrdersController(ApplicationDbContext db, IOrdersService service)
        {
            _db = db;
            _service = service;
        }

        // GET: api/orders
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var orders = await _service.GetAllAsync();
            return Ok(orders);
        }

        // GET: api/orders/{id}
        // ✅ Trả OrderDetailDto để MVC gọi /orders/{id} là dùng được
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var dto = await BuildOrderDetailDtoAsync(id);
            if (dto == null) return NotFound("Order not found");
            return Ok(dto);
        }

        // GET: api/orders/{id}/detail
        // ✅ Alias sang cùng kết quả như GetById
        [HttpGet("{id:int}/detail")]
        public async Task<IActionResult> GetOrderDetail(int id)
        {
            // ví dụ dùng _db hoặc gọi _service
            var dto = await _service.GetOrderDetailAsync(id);
            if (dto == null) return NotFound("Order not found");
            return Ok(dto);
        }

        // POST: api/orders
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Orders model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var created = await _service.CreateAsync(model);
            return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
        }

        // PUT: api/orders/{id}
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] Orders model)
        {
            var ok = await _service.UpdateAsync(id, model);
            if (!ok) return BadRequest("ID không khớp hoặc không tìm thấy order");
            return NoContent();
        }

        // DELETE: api/orders/{id}
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var ok = await _service.DeleteAsync(id);
            if (!ok) return NotFound();
            return NoContent();
        }

        // GET: api/orders/all-by-user/{userId}
        [HttpGet("all-by-user/{userId:int}")]
        public async Task<IActionResult> GetAllByUser(int userId)
            => Ok(await _service.GetOrdersByUserIdAsync(userId));

        // GET: api/orders/all-by-store/{userId}
        [HttpGet("all-by-store/{userId:int}")]
        public async Task<IActionResult> GetAllByStore(int userId)
            => Ok(await _service.GetOrdersByStoreUserAsync(userId));

        // PATCH: api/orders/updatestatus/{id}?status=ChoLayHang
        [HttpPatch("updatestatus/{id:int}")]
        public async Task<IActionResult> UpdateStatus(int id, [FromQuery] OrderStatus status)
        {
            var (success, message) = await _service.UpdateStatusAsync(id, status);
            if (!success) return NotFound(message);
            return Ok(message);
        }

        // GET: api/orders/statistics?storeId=1&start=...&end=...&startCompare=...&endCompare=...
        [HttpGet("statistics")]
        public async Task<IActionResult> GetStatistics(
            [FromQuery] int storeId,
            [FromQuery] DateTime? start,
            [FromQuery] DateTime? end,
            [FromQuery] DateTime? startCompare = null,
            [FromQuery] DateTime? endCompare = null)
        {
            if (storeId <= 0)
                return BadRequest("Thiếu hoặc sai StoreId");

            var result = await _service.GetStatisticsAsync(storeId, start, end, startCompare, endCompare);
            return Ok(result);
        }
        [HttpGet("statistics-by-user/{userId}")]
        public async Task<IActionResult> GetStatisticsByUser(int userId, DateTime? start, DateTime? end, DateTime? startCompare, DateTime? endCompare)
        {
            var result = await _service.GetStatisticsByUserAsync(userId, start, end, startCompare, endCompare);
            return Ok(result);
        }

        // ================== Helpers ==================
        private async Task<OrderDetailDto?> BuildOrderDetailDtoAsync(int id)
        {
            var order = await _db.Orders
                .Include(o => o.OrderDetails)
                    .ThenInclude(od => od.Product)
                .Include(o => o.ShippingMethod)
                .Include(o => o.User)
                .FirstOrDefaultAsync(o => o.Id == id);

            if (order == null) return null;

            return new OrderDetailDto
            {
                OrderId = order.Id,
                OrderDate = order.OrderDate,
                PaymentMethod = order.PaymentMethod ?? "",
                PaymentStatus = order.PaymentStatus ?? "",
                Status = order.Status,
                DeliveryFee = order.DeliveryFee,
                ItemsTotal = order.OrderDetails?.Sum(d => d.Price * d.Quantity) ?? 0,
                TotalPrice = order.TotalPrice,
                ShippingMethodName = order.ShippingMethod?.MethodName,
                CustomerName = order.User?.FullName ?? "",
                CustomerPhone = order.User?.Phone ?? "",
                Items = order.OrderDetails?.Select(d => new OrderDetailItemDto
                {
                    ProductId = d.ProductId,
                    ProductName = d.Product?.Name ?? "Sản phẩm",
                    Image = d.Product?.MainImage,
                    Quantity = d.Quantity,
                    Price = d.Price
                }).ToList() ?? new List<OrderDetailItemDto>(),
                LabelId = order.LabelId
            };
        }
        [HttpGet("{id}/user/{userId}")]
        public async Task<IActionResult> GetByIdForUser(int id, int userId)
        {
            var order = await _service.GetOrderDetailByIdAsync(id, userId);

            if (order == null)
                return NotFound();

            return Ok(order);
        }
        // OrdersController (API)
        [HttpGet("user/{userId}")]
        public async Task<IActionResult> GetOrdersByUser(int userId)
        {
            var data = await _db.Orders
                .Where(o => o.UserId == userId)
                .OrderByDescending(o => o.OrderDate)
                .Select(o => new
                {
                    o.Id,
                    o.OrderDate,
                    o.TotalPrice,
                    o.PaymentMethod,
                    o.PaymentStatus,
                    Status = o.Status.ToString() // ChoXuLy, ChoLayHang, DangGiao, DaHoanThanh, DaHuy
                })
                .ToListAsync();

            return Ok(data);
        }

        [HttpGet("totalprice/by-month/{year}/store/{storeId}")]
        public async Task<IActionResult> GetTotalPriceByMonth(int year, int storeId)
        {
            if (storeId <= 0)
                return BadRequest("Sai storeId");

            var result = await _service.GetTotalPriceByMonthAsync(year, storeId);
            return Ok(result);
        }
        [HttpGet("count/store/{storeId}")]
        public async Task<IActionResult> GetTotalOrdersByStoreId(int storeId)
        {
            var count = await _service.GetTotalOrdersByStoreIdAsync(storeId);
            return Ok(count);
        }
        [HttpPost("send/all/current-month")]
        public async Task<IActionResult> SendAllStoresRevenueReportCurrentMonth()
        {
            try
            {
                await _service.SendRevenueReportAllStoresCurrentMonthAsync();
                return Ok(new { success = true, message = "Đã gửi báo cáo doanh thu tháng hiện tại cho toàn bộ store!" });
            }
            catch (System.Exception ex)
            {
                return BadRequest(new { success = false, message = $"Lỗi: {ex.Message}" });
            }
        }
        [HttpGet("total-revenue")]
        public async Task<IActionResult> GetTotalRevenue()
        {
            var total = await _service.GetTotalRevenueAsync();
            return Ok(total);
        }
        /// <summary>
        /// Thanh toán COD (tạo đơn bên GHTK và trả lại LabelId)
        /// </summary>
        [HttpPost("cod/{orderId}")]
        public async Task<IActionResult> CheckoutCOD(int orderId)
        {
            var label = await _service.PushOrderToGhtkAndSaveLabelAsync(orderId);

            if (string.IsNullOrEmpty(label))
                return BadRequest(new { message = "Không tạo được đơn hàng COD bên GHTK." });

            return Ok(new
            {
                message = "Đặt hàng COD thành công.",
                labelId = label
            });
        }


        [HttpPost("{id:int}/cancel/user/{userId:int}")]
        public async Task<IActionResult> CancelOrder(int id, int userId)
        {
            var result = await _service.CancelOrderAsync(id, userId);

            if (!result.Success)
                return BadRequest(new { message = result.Message });

            return Ok(new { message = result.Message });
        }

        // Controller
        [HttpPatch("{id:int}/nextstatus")]
        public async Task<IActionResult> UpdateToNextStatus(int id)
        {
            var (success, message, status) = await _service.UpdateToNextStatusAsync(id);
            if (!success) return BadRequest(new { message, status });
            return Ok(new { message, status = status.ToString() });
        }


    }
}